# ahsorioles
This is our high school website...a definite work in progress.

Hexcodes to use for certain colors:
Orange #f05b22

